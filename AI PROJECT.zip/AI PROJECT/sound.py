from playsound import playsound
playsound("chk_sound.wav")

